// old_hello.cpp
#include "std_lib_facilities.h" 
int main() {
	cout << "The rather old \"Hello, World!\" message\n";
	// keep_window_open(); // Not needed when using project template TDT4102_std_lib_facilities 
	return 0;
}